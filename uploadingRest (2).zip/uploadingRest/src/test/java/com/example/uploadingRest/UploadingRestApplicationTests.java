package com.example.uploadingRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadingRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
