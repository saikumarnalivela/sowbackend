package com.example.uploadingRest.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.apache.poi.ss.usermodel.Cell;
import org.springframework.stereotype.Component;

@Entity
public class SowMaster {
	
	@Id
	@Column(name = "SOW_ID",nullable = false)
	private String sowId;
	
	@Column(name = "Project_Code",nullable = false)
	private double projectCode;
	
	@Column(name = "Project_Name",nullable = false)
	private String projectName;
	
	@Column(name = "segment",nullable = false)
	private String segment;
	
	@Column(name = "mappingType",nullable = false)
	private String mappingType;
	
	@Column(name = "status",nullable = false)
	private String status;
	
	@Column(name = "type",nullable = false)
	private String type;
	
	@Column(name = "sourceData",nullable = false)
	private String sourceData;
	
	@Column(name = "souIdDump",nullable = false)
	private String sowIdDump;
	
	@Column(name = "citiReference",nullable = false)
	private String citiReference;
	
	@Column(name = "Commencement_Date",nullable = false)
	private Date startDate;
	
	@Column(name = "Expiry_Date",nullable = false)
	private Date endDate;
	
	@Column(name = "tech",nullable = false)
	private String tech;
	
	@Column(name = "businessUnit",nullable = false)
	private String businessUnit;
	
	@Column(name = "contract",nullable = false)
	private String contract;
	
	@Column(name = "citilegalEntity",nullable = false)
	private String citiLegalEntity;
	
	@Column(name = "geograpy",nullable = false)
	private String Geograpy;
	
	@Column(name = "sector",nullable = false)
	private String sector;
	
	@Column(name = "sowOwner",nullable = false)
	private String sowOwner;
	
	@Column(name = "sowOwnerEmail",nullable = false)
	private String sowOwnerEmail;
	
	@Column(name = "citiPM",nullable = false)
	private String citiPM;
	
	@Column(name = "citiPMMail",nullable = false)
	private String citiPmMail;
	
	@Column(name = "sowLocations",nullable = false)
	private String sowLocations;
	
	@Column(name = "supplier",nullable = false)
	private double supplier;
	
	@Column(name = "recoveryTime",nullable = false)
	private String recoveryTime;
	
	@Column(name = "ApplicationUses",nullable = false)
	private String ApplicationUses;
	
	@Column(name = "HighestConfidence",nullable = false)
	private String highConfidence;
	
	@Column(name = "remarks")
	private String remarks;
	
	@Column(name = "recordsPerProject")
	private double recordsPerProject;
	
	@Column(name = "program")
	private String program;
	
	@Column(name = "spoc")
	private String spoc;

	public String getSowId() {
		return sowId;
	}

	public void setSowId(String sowId) {
		this.sowId = sowId;
	}

	public double getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(double projectCode) {
		this.projectCode = projectCode;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getSegment() {
		return segment;
	}

	public void setSegment(String segment) {
		this.segment = segment;
	}

	public String getMappingType() {
		return mappingType;
	}

	public void setMappingType(String mappingType) {
		this.mappingType = mappingType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSourceData() {
		return sourceData;
	}

	public void setSourceData(String sourceData) {
		this.sourceData = sourceData;
	}

	public String getSowIdDump() {
		return sowIdDump;
	}

	public void setSowIdDump(String sowIdDump) {
		this.sowIdDump = sowIdDump;
	}

	public String getCitiReference() {
		return citiReference;
	}

	public void setCitiReference(String citiReference) {
		this.citiReference = citiReference;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getTech() {
		return tech;
	}

	public void setTech(String tech) {
		this.tech = tech;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public String getCitiLegalEntity() {
		return citiLegalEntity;
	}

	public void setCitiLegalEntity(String citiLegalEntity) {
		this.citiLegalEntity = citiLegalEntity;
	}

	public String getGeograpy() {
		return Geograpy;
	}

	public void setGeograpy(String geograpy) {
		Geograpy = geograpy;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getSowOwner() {
		return sowOwner;
	}

	public void setSowOwner(String sowOwner) {
		this.sowOwner = sowOwner;
	}

	public String getSowOwnerEmail() {
		return sowOwnerEmail;
	}

	public void setSowOwnerEmail(String sowOwnerEmail) {
		this.sowOwnerEmail = sowOwnerEmail;
	}

	public String getCitiPM() {
		return citiPM;
	}

	public void setCitiPM(String citiPM) {
		this.citiPM = citiPM;
	}

	public String getCitiPmMail() {
		return citiPmMail;
	}

	public void setCitiPmMail(String citiPmMail) {
		this.citiPmMail = citiPmMail;
	}

	public String getSowLocations() {
		return sowLocations;
	}

	public void setSowLocations(String sowLocations) {
		this.sowLocations = sowLocations;
	}

	public double getSupplier() {
		return supplier;
	}

	public void setSupplier(double supplier) {
		this.supplier = supplier;
	}

	public String getRecoveryTime() {
		return recoveryTime;
	}

	public void setRecoveryTime(String recoveryTime) {
		this.recoveryTime = recoveryTime;
	}

	public String getApplicationUses() {
		return ApplicationUses;
	}

	public void setApplicationUses(String applicationUses) {
		ApplicationUses = applicationUses;
	}

	public String getHighConfidence() {
		return highConfidence;
	}

	public void setHighConfidence(String highConfidence) {
		this.highConfidence = highConfidence;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public double getRecordsPerProject() {
		return recordsPerProject;
	}

	public void setRecordsPerProject(double recordsPerProject) {
		this.recordsPerProject = recordsPerProject;
	}

	public String getProgram() {
		return program;
	}

	public void setProgram(String program) {
		this.program = program;
	}

	public String getSpoc() {
		return spoc;
	}

	public void setSpoc(String spoc) {
		this.spoc = spoc;
	}
	
	
	
	

	
	
	
	
}
