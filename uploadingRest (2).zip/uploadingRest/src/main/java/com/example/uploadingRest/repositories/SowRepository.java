package com.example.uploadingRest.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.uploadingRest.models.SowMaster;

@Repository
public interface SowRepository extends JpaRepository<SowMaster, String>{

}
