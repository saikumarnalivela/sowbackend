package com.example.uploadingRest.services;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.uploadingRest.models.SowMaster;
import com.example.uploadingRest.repositories.SowRepository;

@Service
public class SowService {

	@Autowired
	SowRepository sowRepo;

//	@Autowired
//	SowMaster sowmaster;
//  Tightly Coupled
	SowMaster sow = new SowMaster();
	// HashMap
	/*
	 * private static String[] initMethods = { "setSowId", "setContractName",
	 * "setSignedEffectiveDate","setStartDate","setEndDate","setTenure" };
	 * 
	 * private static Method getMethod(int index) throws NoSuchMethodException { if
	 * ((index < 0) || (index > initMethods.length - 1)) return null; Class
	 * sowMaster = SowMaster.class; return sowMaster.getMethod(initMethods[index],
	 * String.class); }
	 */

	public String phraseFile(String file) throws IllegalStateException, IOException {
		
		try
        {
            //Create Workbook instance holding reference to .xlsx file
            XSSFWorkbook workbook = new XSSFWorkbook(file);
 
            //Get first/desired sheet from the workbook
            XSSFSheet sheet = workbook.getSheetAt(0);
 
            //Iterate through each rows one by one
            Iterator<Row> rowIterator = sheet.iterator();
            rowIterator.next();
            while (rowIterator.hasNext()) 
            {
                Row row = rowIterator.next(); 
                
               
                Iterator<Cell> cellIterator = row.cellIterator();
                while (cellIterator.hasNext()) 
                {
                    Cell cell = cellIterator.next();
                    /*Method m =  getMethod(cell.getColumnIndex());
                    System.out.println(m.getName()); 
                    System.out.println( "    " +m.getName().equals("setSignedEffectiveDate"));
                    if (m.getName().equals("setSignedEffectiveDate") || m.getName().equals("setStartDate") || m.getName().equals("setStartDate")) {
                    	m.invoke(sow, cell.getDateCellValue());
                    }else if (m.getName().equals("tenture")) {
                    	m.invoke(sow, cell.getNumericCellValue());
                    }else {
                    	m.invoke(sow, cell.getStringCellValue());
                    }*/
                    //System.out.println(m);
                    //m.invoke(sow, cell.getStringCellValue());
                    switch(cell.getColumnIndex()){
                    case 0:
                    	System.out.print(cell.getNumericCellValue() + "	| ");
                    	sow.setProjectCode(cell.getNumericCellValue());
                    	break;
                    case 1: 
                    	System.out.print(cell.getStringCellValue() + "	| ");
                    	sow.setProjectName(cell.getStringCellValue());
                    	break;
                    case 2: 
                    	System.out.print(cell.getStringCellValue() + "	| ");
                    	sow.setSegment(cell.getStringCellValue());
                    	break;
                    case 3: 
                    	System.out.print(cell.getStringCellValue()+ "	| ");
                    	sow.setMappingType(cell.getStringCellValue());
                    	break;
                    case 4: 
                    	System.out.print(cell.getStringCellValue()+ "	| ");
                    	sow.setStatus(cell.getStringCellValue());
                    	break;
                    case 5: 
                    	System.out.print(cell.getStringCellValue()+ "	| ");
                    	sow.setType(cell.getStringCellValue());
                    	break;
					
					  case 6: 
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setSourceData(cell.getStringCellValue());
						  break; 
					  case 7:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setSowIdDump(cell.getStringCellValue());
						  break; 
					  case 8:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setCitiReference(cell.getStringCellValue());
						  break; 
					  case 9:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setSowId(cell.getStringCellValue());
						  break; 
					  case 10:
						  System.out.print(cell.getDateCellValue()+ "	| ");
						  sow.setStartDate(cell.getDateCellValue());
						  break; 
					  case 11:
						  System.out.print(cell.getDateCellValue()+ "	| ");
						  sow.setEndDate(cell.getDateCellValue()); 
						  break; 
					  case 12:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setTech(cell.getStringCellValue());
						  break; 
					  case 13:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setBusinessUnit(cell.getStringCellValue());
						  break; 
					  case 14:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setContract(cell.getStringCellValue());
						  break; 
					  case 15:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setCitiLegalEntity(cell.getStringCellValue());
						  break; 
					  case 16:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setGeograpy(cell.getStringCellValue());
						  break; 
					  case 17:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setSector(cell.getStringCellValue());
						  break; 
					  case 18:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setSowOwner(cell.getStringCellValue()); 
						  break; 
					  case 19:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setSowOwnerEmail(cell.getStringCellValue()); 
						  break; 
					  case 20:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setCitiPM(cell.getStringCellValue());
						  break; 
					  case 21:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setCitiPmMail(cell.getStringCellValue());
						  break; 
					  case 22:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setSowLocations(cell.getStringCellValue());
						  break; 
					  case 23:
						  System.out.print(cell.getNumericCellValue()+ "	| ");
						  sow.setSupplier(cell.getNumericCellValue());
						  break; 
					  case 24:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setRecoveryTime(cell.getStringCellValue());
						  break; 
					  case 25:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setApplicationUses(cell.getStringCellValue());
						  break; 
					  case 26:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setHighConfidence(cell.getStringCellValue()); 
						  break; 
					  case 27:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setRemarks(cell.getStringCellValue());
						  break; 
					  case 28:
						  System.out.print(cell.getNumericCellValue()+ "	| ");
						  sow.setRecordsPerProject(cell.getNumericCellValue());
						  break; 
					  case 29:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setProgram(cell.getStringCellValue());
						  break; 
					  case 30:
						  System.out.print(cell.getStringCellValue()+ "	| ");
						  sow.setSpoc(cell.getStringCellValue());
						  break; 
                    }
                    
                }
                sowRepo.save(sow);
                System.out.println("");
            
            }
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
		finally {
			System.out.println("In finally block");
			
		}
		return "Saved Successfully";
	}
}
